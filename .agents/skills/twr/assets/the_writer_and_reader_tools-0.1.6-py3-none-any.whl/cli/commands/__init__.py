"""Argparse command registration modules."""
